module.exports = [
    {
        keys: ["comida", "fome", "comer"],
        messages: ["tb to, bora pizza😜", "comi meu 🍍", "tem pipoca no freezer", "fazer as compras com o dindin do ex🤤"]
    },
    {
        keys: ["namora", "casar", "casada"],
        messages: ["casada??", "namoro seu primo(a)", "famosinha do tts", "pra vc nunca"],

    },
    {
        keys: ["sono", "dormir", "off"],
        messages: ["vai dormir 🤪", "cafe sem ou com leite 🤗", "come um cacetinho🍞"]

    },
    {
        keys: ["filme", "filminho", "cinema"],
        messages: ["50 tons de cinza", "sua mãe na minha cama", "titanic", "frozen.. lerigou", "batman vs superman", "coringa", "uma noite no museu"]
    },
    {
        keys: ["geladeira", "dispensa", "lancheira"],
        messages: ["assaltei a tua😅", "tá vazia", "roubaram a minha 😢"]

    },
    {
        keys: ["ama", "gosta", "adora", "gostando", "gostou"],
        messages: ["ti odeio🥵", "meu morzinho(a)", "amar é algo muito forte", "amo sua mãe tb", "ama ver anime", "amo muito vc princesa", "amor dimais", "amo comer vc"]
    },
    {
        keys: ["tapa", "tapinha", "bate"],
        messages: ["so se for na tua bunda", "tapa na cara??", "tapa no visual🙃"]
    },
    {
        keys: ["cansada", "exausta", "soninho"],
        messages: ["eu domir depois.. quero zuar", "vai vc 🥲", "dormir é pros fracos"]
    },
    {
        keys: ["pai", "mae", "pais", "criador"],
        messages: ["o meu foi comprar farinha", "atrazou minha pensão😢", "pai olhando hentae", "feita pela mika e rimuru", "rimuru o mais gotosu"]
    },
    {
        keys: ["feio", "feia", "horrorosa", "fedida"],
        messages: ["concordo, vc é feio", "feio mais gostoso(a)", "100% feio", "feio parace um bicho"]
    },
    {
        keys: ["gf", "call", "liga"],
        messages: ["vai gemer pra mim.?", "coloca uma musica braba..", "bora call", "vc broxou no GF", "durou nem 2 minutos"]
    },
    {
        keys: ["akame", "rimuru", "amigo"],
        messages: ["é broxa", "pau pequeno", "deu pros crias", "tem medo da duda"]
    },
    {
        keys: ["curti", "me", "adora"],
        messages: ["gosto naum", "gosto sim", "gostando tals", "gosta nada😝", "já gostei", "to gostando", "gosto pra krai"]
    },
    {
        keys: ["preferida", "favorita", "especial"],
        messages: ["aberta a sugestões..", "todas🤪", "gosto de uma ae"]
    },
    {
        keys: ["anime", "manga", "hentai"],
        messages: ["naruto é bom", "Jujutsu Kaisen", "Demon Slayer", "My Hero Academia", "Attack on Titan", "One Piece", "dragon boll", "pokemom show 🤪"]
    }, ,
    {
        keys: ["beleza", "bonita", "gostosa"],
        messages: ["sou linda", "mais bonita que vc.. grr", "sou linda e cheirosa😌"]
    },
    {
        keys: ["femea", "mulher", "lesbica", "bumbum", "bunda"],
        messages: ["uma deusa", "uma gata", "femea", "uma princesa", "uma dama"]
    },
    {
        keys: ["gay", "viado", "veado", "broxa"],
        messages: ["vc é mais gay", "seu primo é gay", "so tem gay aqui", "o mais gay ☝", "gay é o kosame", "gay é vc🤗"]
    },
    ,
    {
        keys: ["burra", "idiota", "jumenta", "analfabeta"],
        messages: ["naum sou burra", "burra naum", "ezquizofrenia", "inveja??", "sou nerdola", "quanto é 56÷34%68 ao quadrado??", "sou da nasa fii"]
    },
    {
        keys: ["fotinha", "peitinho", "pack", "nude", "nudes"],
        messages: ["manda vc", "só para amigos", "sou timida", "pede pro de cima ☝", "50 pila a foto🙃", "mando só em pix"]
    }, ,
    {
        keys: ["mama", "leite", "leitinho"],
        messages: ["vc mamou primeiro", "sou alergica a seu leite", "somente agua", "vc é broxa só tem ar ae", "só nescau"]
    }, ,
    {
        keys: ["acha", "axa", "achou"],
        messages: ["acho nada", "acho bom", "acho um 💩", "acho gringe", "acho lindo"]
    }, ,
    {
        keys: ["beija", "beijou", "beijinho", "beijo", "boca"],
        messages: ["beija seu amigo gay", "me beija depois do pix", "beijar vc é melhor", "beijo todos", "beijar é melhor dar"]
    },
    {
        keys: ["vagabunda", "arrombada", "disgraçada"],
        messages: ["epa sou uma dama", "vc é mais", "sou nada", "olhando muita besteira", "cade a educação", "sou iiso naum"]
    },
    {
        keys: ["amore", "amada", "casar", "casal", "casamento"],
        messages: ["amor o krai", "amor de pedreiro", "amor faz a janta", "amor do rimuru", "amor de mentira", "amor de novela", "amor de verdade"]
    },
    {
        keys: ["dar", "meter", "soca"],
        messages: ["da vc", "dar oq?", "ja dei", "damos juntos", "dando nesse horas"]
    },
    {
        keys: ["faz", "escreve", "cria"],
        messages: ["faz vc", "fazer oq", "fazendo", "não fazer"]
    },
    {
        keys: ["fez", "limpa", "fazer", "vaz", "manda"],
        messages: ["faz vc osh", "nd fazer oq", "to fazendo ja", "não sei fazer"]
    },
    {
        keys: ["sexo", "transar", "seqsu", "gemer"],
        messages: ["vc é broxa", "vc ja broxou cmg", "olha quem fala", "vc é 100% broxa", "broxa dimais vc"]
    }
]
