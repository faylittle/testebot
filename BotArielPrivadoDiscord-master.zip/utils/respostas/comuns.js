module.exports = {
  keys: [
    "fome", "namora", "dia", "filme", "geladeira", "ama", "tapa", "dormir", "pai", "feio", "call", "akame", "gosta", "favorita", "anime",
    "feia", "mulher", "gay", "burra", "fotinha", "mama", "acha", "beija", "vagabunda", "amor", "dar", "faz", "fazer", "broxa"
  ],
  values: [
    ["tb to, bora pizza😜", "comi meu 🍍", "tem pipoca no freezer", "fazer as compras com o dindin do ex🤤"],
    ["casada??", "namoro seu primo(a)", "famosinha do tts", "pra vc nunca"],
    ["vai dormir 🤪", "cafe sem ou com leite 🤗", "come um cacetinho🍞"],
    ["50 tons de cinza", "sua mãe na minha cama", "titanic", "frozen.. lerigou", "batman vs superman", "coringa", "uma noite no museu"],
    ["assaltei a tua😅", "tá vazia", "roubaram a minha 😢"],
    ["ti odeio🥵", "meu morzinho(a)", "amar é algo muito forte", "amo sua mãe tb", "ama ver anime", "amo muito vc princesa", "amor dimais", "amo comer vc"],
    ["so se for na tua bunda", "tapa na cara??", "tapa no visual🙃"],
    ["eu domir depois.. quero zuar", "vai vc 🥲", "dormir é pros fracos"],
    ["o meu foi comprar farinha", "atrazou minha pensão😢", "pai olhando hentae", "feita pela mika e rimuru", "rimuru o mais gotosu"],
    ["concordo, vc é feio", "feio mais gostoso(a)", "100% feio", "feio parace um bicho"],
    ["vai gemer pra mim.?", "coloca uma musica braba..", "bora call", "vc broxou no GF", "durou nem 2 minutos"],
    ["é broxa", "pau pequeno", "deu pros crias", "tem medo da duda"],
    ["gosto naum", "gosto sim", "gostando tals", "gosta nada😝", "já gostei", "to gostando", "gosto pra krai"],
    ["aberta a sugestões..", "todas🤪", "gosto de uma ae"],
    ["naruto é bom", "Jujutsu Kaisen", "Demon Slayer", "My Hero Academia", "Attack on Titan", "One Piece", "dragon boll", "pokemom show 🤪"],
    ["sou linda", "mais bonita que vc.. grr", "sou linda e cheirosa😌"],
    ["uma deusa", "uma gata", "femea", "uma princesa", "uma dama"],
    ["vc é mais gay", "seu primo é gay", "so tem gay aqui", "o mais gay ☝", "gay é o kosame", "gay é vc🤗"],
    ["naum sou burra", "burra naum", "ezquizofrenia", "inveja??", "sou nerdola", "quanto é 56÷34%68 ao quadrado??", "sou da nasa fii"],
    ["manda vc", "só para amigos", "sou timida", "pede pro de cima ☝", "50 pila a foto🙃", "mando só em pix"],
    ["vc mamou primeiro", "sou alergica a seu leite", "somente agua", "vc é broxa só tem ar ae", "só nescau"],
    ["acho nada", "acho bom", "acho um 💩", "acho gringe", "acho lindo"],
    ["beija seu amigo gay", "me beija depois do pix", "beijar vc é melhor", "beijo todos", "beijar é melhor dar"],
    ["epa sou uma dama", "vc é mais", "sou nada", "olhando muita besteira", "cade a educação", "sou iiso naum"],
    ["amor o krai", "amor de pedreiro", "amor faz a janta", "amor do rimuru", "amor de mentira", "amor de novela", "amor de verdade"],
    ["da vc", "dar oq?", "ja dei", "damos juntos", "dando nesse horas"],
    ["faz vc", "fazer oq", "fazendo", "não fazer"],
    ["faz vc osh", "nd fazer oq", "to fazendo ja", "não sei fazer"],
    ["vc é broxa", "vc ja broxou cmg", "olha quem fala", "vc é 100% broxa", "broxa dimais vc"]
  ]
}
