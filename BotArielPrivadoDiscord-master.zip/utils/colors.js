module.exports = {
  primary: "#97cff3",
  secondary: "#1351d8",
  error: ""
}
